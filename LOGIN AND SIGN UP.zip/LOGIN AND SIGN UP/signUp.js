function getValues() {  
    let Name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password1").value;
// console.log("name: "+Name+", email: "+email+", password: "+password);

const jsonData =JSON.stringify({
        name: Name,
        email: email,
        password: password
    })
console.log(jsonData);
    
fetch("https://anicare.herokuapp.com/api/auth/signup",{
    method:'POST',
    headers:{
        "Content-Type": "application/json",
        "Accept": "application/json"
    },
    body: jsonData
    // JSON.stringify({
    //     name: Name,
    //     email: email,
    //     password: password
    // })
})
.then(res=>{
    if(res.ok){
        console.log("Successful")
        window.location.href ="./LOGIN.html"
    }else{
        console.log("failed");
    }
    return res.json() 
})
.then(data =>{
    console.log("Data=>", data);
})
.catch(error =>{
    console.log(error);
})
  }