function getValues() {  
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

const jsonData =JSON.stringify({
        email: email,
        password: password
    })
console.log(jsonData);
    
fetch("https://anicare.herokuapp.com/api/auth/login",{
    method:'POST',
    headers:{
        "Content-Type": "application/json",
        "Accept": "application/json"
    },
    body: jsonData
})
.then(res=>{
    if(res.ok){
        console.log("Successful");
        window.location.href ="../DASH and MSG/dashboard.html"
    }else{
        console.log("failed");
    }
    return res.json() 
})
.then(data =>{
    console.log("Data=>", data.data.token);
    localStorage.getItem('Data',data);
    sessionStorage.setItem("Data", data.data.token)
})
.catch(error =>{
    console.log(error);
})
  }
