function myFunction() {
    window.location.href ="./LOGIN.html"
  }
      setTimeout(function(){myFunction()},3000);