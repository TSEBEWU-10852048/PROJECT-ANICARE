
    
    const labels = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
    ];
  
    const data = {
      labels: labels,
      datasets: [{
        label: 'Temperature',
        backgroundColor: '#C8DDF8',
        borderColor: '#C8DDF8',
        data: [0, 10, 5, 2, 20, 50, 45],
      }]
    };
  
    const config = {
      type: 'line',
      data: data,
      options: {}
    };


const myChart = new Chart(
  document.getElementById('myChart'),
  config
);

    const labels1 = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
    ];
  
    const data1 = {
      labels: labels1,
      datasets: [{
        label: 'Pulse rate',
        backgroundColor: '#7BFFB4',
        borderColor: '#7BFFB4',
        data: [0, 10, 5, 2, 20, 50, 45],
      }]
    };
  
    const config1 = {
      type: 'line',
      data: data1,
      options: {}
    };


const myChart1 = new Chart(
  document.getElementById('myChart1'),
  config1
);
  
    
        // When the user clicks on div, open the popup
        function myFunction() {
          var popup = document.getElementById("myPopup");
          popup.classList.toggle("show");
        }






        var NumDevices;
        const results = sessionStorage.getItem('Data');
        console.log("data=>",results);
        function getReadings() {  
      
      // const jsonData =JSON.stringify({
      //         email: email,
      //         password: password
      //     })
      // console.log(jsonData);
          
      fetch("https://anicare.herokuapp.com/api/readings",{
          method:'GET',
          headers:{
              "Content-Type": "application/json",
              "Accept": "application/json",
              "Authorization": "Bearer "+results
          },
          // body: jsonData
      })
      .then(res=>{
          if(res.ok){
              console.log("Successful")
              // window.location.href ="../messages.html"
          }else{
              console.log("failed");
          }
          return res.json() 
      })
      .then(data =>{
          console.log("Data=>", data.data.length);
          NumDevices = data.data.length;
          document.getElementById('result').innerHTML = NumDevices;
      })
      .catch(error =>{
          console.log(error);
      })
        }
      